package com.ajou.capstonedesign.museapplication;

public class ChooseShoolAdapter {
}
