package com.ajou.capstonedesign.museapplication;

public interface MyItemClickListner {
    void onClickMeClick(int position);
    void onItemClick(int position);
}
