package com.ajou.capstonedesign.museapplication;

public class MajorList {
    private String major;

    public MajorList(String major){
        this.major = major;
    }

    public String getMajor(){
        return major;
    }
}
