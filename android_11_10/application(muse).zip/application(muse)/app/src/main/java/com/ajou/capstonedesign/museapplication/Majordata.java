package com.ajou.capstonedesign.museapplication;

public class Majordata {
    private String majordata;

    public String getMajordata() {
        return majordata;
    }

    public void setMajordata(String majordata) {
        this.majordata = majordata;
    }
}
